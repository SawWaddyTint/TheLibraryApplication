import 'package:TheLibraryApplication/data/vos/book_list_vo.dart';
import 'package:TheLibraryApplication/data/vos/book_vo.dart';
import 'package:TheLibraryApplication/data/vos/books_by_list_name_vo.dart';

abstract class BookModel {
  Future<List<BookListVO>> getBookOverviewList();
  Future<List<BookVO>> getBooksByListName(String listName);

  Stream<List<BookListVO>> getBookOverviewListFromDatabase();
  Stream<List<BookVO>> getBooksByListNameFromDatabase(String listName);

  void saveReadBooks(BookVO book);
  Stream<List<BookVO>> getReadBooksFromDatabase();
}
