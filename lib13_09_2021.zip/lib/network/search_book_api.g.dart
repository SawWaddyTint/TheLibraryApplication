// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'search_book_api.dart';

// **************************************************************************
// RetrofitGenerator
// **************************************************************************

class _SearchBookApi implements SearchBookApi {
  _SearchBookApi(this._dio, {this.baseUrl}) {
    ArgumentError.checkNotNull(_dio, '_dio');
    baseUrl ??= 'https://www.googleapis.com/books/v1';
  }

  final Dio _dio;

  String baseUrl;

  @override
  Future<SearchBookResponse> getSearchBooks(q) async {
    ArgumentError.checkNotNull(q, 'q');
    const _extra = <String, dynamic>{};
    final queryParameters = <String, dynamic>{r'q': q};
    final _data = <String, dynamic>{};
    final _result = await _dio.request<Map<String, dynamic>>('/volumes',
        queryParameters: queryParameters,
        options: RequestOptions(
            method: 'GET',
            headers: <String, dynamic>{},
            extra: _extra,
            baseUrl: baseUrl),
        data: _data);
    final value = SearchBookResponse.fromJson(_result.data);
    return value;
  }
}
