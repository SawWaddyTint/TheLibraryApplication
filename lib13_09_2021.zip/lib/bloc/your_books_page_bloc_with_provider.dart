import 'package:TheLibraryApplication/data/models/book_model.dart';
import 'package:TheLibraryApplication/data/models/book_model_impl.dart';
import 'package:TheLibraryApplication/data/vos/book_vo.dart';

import 'package:TheLibraryApplication/data/vos/books_by_list_name_vo.dart';
import 'package:flutter/foundation.dart';

class YourBooksPageBlocWithProvider extends ChangeNotifier {
  // States
  List<BookVO> readBooks;
  int layoutIndexForBooks = 1;
  String sortedType = "Recent";
  int selectedView;
  bool showDowloadAndNotDownloaded = true;
  bool showNotStartedAndShowInProgess = true;
  bool showSelectedFilter = false;
  bool showListView = true;
  bool showLargeGrid = false;
  bool showSmallGrid = false;
  int layoutIndex;
  List<String> selectedType = [];
  List<String> filterType = [
    "Downloaded",
    "Not downloaded",
    "Not started",
    "In progress",
  ];

  /// Models
  BookModel bookModel = BookModelImpl();

  YourBooksPageBlocWithProvider({String listName}) {
    bookModel.getReadBooksFromDatabase().listen((bList) {
      readBooks = bList;
      layoutIndexForBooks = 1;
      notifyListeners();
    }).onError((error) {
      debugPrint(error.toString());
    });
  }

  void changeLayoutStyle(int layoutIndex) {
    if (layoutIndex == 1) {
      layoutIndexForBooks = 1;
      notifyListeners();
    } else if (layoutIndex == 2) {
      layoutIndexForBooks = 2;
      notifyListeners();
    } else {
      layoutIndexForBooks = 3;
      notifyListeners();
    }
  }

  void getSelectedItems(String selected) {
    if (selected == "Downloaded") {
      _addItemToSelectedType(selected);

      showDowloadAndNotDownloaded = false;
      showSelectedFilter = true;
      notifyListeners();
    }

    if (selected == "Not downloaded") {
      _addItemToSelectedType(selected);

      showDowloadAndNotDownloaded = false;
      showSelectedFilter = true;
      notifyListeners();
    }

    if (selected == "Not started") {
      _addItemToSelectedType(selected);
      showNotStartedAndShowInProgess = false;
      showSelectedFilter = true;
      notifyListeners();
    }

    if (selected == "In progress") {
      _addItemToSelectedType(selected);

      showNotStartedAndShowInProgess = false;
      showSelectedFilter = true;
      notifyListeners();
    }
  }

  void _addItemToSelectedType(String type) {
    selectedType.add(type);
    notifyListeners();
  }

  void removeFilters() {
    selectedType = [];
    showSelectedFilter = false;
    showDowloadAndNotDownloaded = true;
    showNotStartedAndShowInProgess = true;
    notifyListeners();
  }

  void sortedBySelectedIndex(int value) {
    if (value == 1) {
      readBooks.sort((a, b) {
        return a.createdDate.compareTo(b.createdDate);
      });
      sortedType = "Recent";
      notifyListeners();
    }
    if (value == 2) {
      readBooks.sort((a, b) {
        return a.title.compareTo(b.title);
      });
      sortedType = "Title";
      notifyListeners();
    } else if (value == 3) {
      readBooks.sort((a, b) {
        return a.author.compareTo(b.author);
      });
      sortedType = "Author";
      notifyListeners();
    }
  }
}
