import 'package:TheLibraryApplication/resources/colors.dart';
import 'package:flutter/material.dart';

class SearchBooksPage extends StatefulWidget {
  @override
  _SearchBooksPageState createState() => _SearchBooksPageState();
}

class _SearchBooksPageState extends State<SearchBooksPage> {
  int charLength = 0;
  TextEditingController textController = TextEditingController();
  bool hasValue = false;
  bool showCreatedShelf = false;

  _onChanged(String value) {
    setState(() {
      charLength = value.length;
    });

    if (charLength > 0) {
      setState(() {
        hasValue = true;
        //leadingIcon = Icon(Icons.download_done_outlined, color: LABEL_COLOR);
      });
    } else {
      setState(() {
        hasValue = false;
        //leadingIcon = Icon(Icons.arrow_back_ios, color: LABEL_COLOR);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          color: Colors.white,
          child: Column(
            children: [
              Container(
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(14.0),
                      child: GestureDetector(
                        child: Icon(
                          Icons.arrow_back_ios,
                          color: LABEL_COLOR,
                          size: 20.0,
                        ),
                        onTap: () {
                          Navigator.pop(context);
                        },
                      ),
                    ),
                    Flexible(
                      child: TextField(
                        controller: textController,
                        style: TextStyle(
                            // fontSize: 28.0,
                            // fontWeight: FontWeight.w600,
                            ),
                        decoration: InputDecoration(
                          hintText: "Shelf name ",
                          border: InputBorder.none,
                          suffix: GestureDetector(
                            child: Visibility(
                              visible: hasValue,
                              child: Padding(
                                padding: const EdgeInsets.only(right: 14.0),
                                child: Icon(
                                  Icons.clear_outlined,
                                  color: LABEL_COLOR,
                                  size: 20.0,
                                ),
                              ),
                            ),
                            onTap: () {
                              _onChanged("");
                              textController.clear();
                            },
                          ),
                        ),
                        onChanged: _onChanged,
                        // maxLength: 50,
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
