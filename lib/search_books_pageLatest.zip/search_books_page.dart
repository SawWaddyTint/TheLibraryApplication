import 'package:TheLibraryApplication/bloc/search_books_page_bloc_with_provider.dart';
import 'package:TheLibraryApplication/components/debouncer.dart';
import 'package:TheLibraryApplication/data/vos/search_book_vo.dart';
import 'package:TheLibraryApplication/resources/colors.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SearchBooksPage extends StatelessWidget {
  TextEditingController textController = TextEditingController();
  final debouncer = Debouncer(milliseconds: 500);
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (BuildContext context) => SearchBooksPageBlocWithProvider(),
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
          body: Container(
            color: Colors.white,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(14.0),
                          child: GestureDetector(
                            child: Icon(
                              Icons.arrow_back_ios,
                              color: LABEL_COLOR,
                              size: 20.0,
                            ),
                            onTap: () {
                              Navigator.pop(context);
                            },
                          ),
                        ),
                        Selector<SearchBooksPageBlocWithProvider, bool>(
                            selector: (context, bloc) => bloc.hasValue,
                            builder:
                                (BuildContext context, hasValue, Widget child) {
                              return Flexible(
                                child: TextField(
                                    controller: textController,
                                    style: TextStyle(
                                        // fontSize: 28.0,
                                        // fontWeight: FontWeight.w600,
                                        ),
                                    decoration: InputDecoration(
                                      hintText: "Search Play Books ",
                                      border: InputBorder.none,
                                      suffix: GestureDetector(
                                        child: Visibility(
                                          visible: hasValue,
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                right: 14.0),
                                            child: Icon(
                                              Icons.clear_outlined,
                                              color: LABEL_COLOR,
                                              size: 20.0,
                                            ),
                                          ),
                                        ),
                                        onTap: () {
                                          onChanged(context, "");
                                          textController.clear();
                                        },
                                      ),
                                    ),
                                    onChanged: (value) => debouncer.run(() {
                                          onChanged(context, value);
                                        })

                                    // maxLength: 50,
                                    ),
                              );
                            }),
                      ],
                    ),
                  ),
                  Divider(
                    thickness: 0.8,
                  ),
                  Selector<SearchBooksPageBlocWithProvider, bool>(
                      selector: (context, bloc) => bloc.showSearchedList,
                      builder: (BuildContext context, showSearchedList,
                          Widget child) {
                        return Visibility(
                          visible: showSearchedList,
                          child: Selector<SearchBooksPageBlocWithProvider,
                              List<SearchBookVO>>(
                            selector: (context, bloc) => bloc.searchBooksList,
                            builder: (BuildContext context, searchBooksList,
                                Widget child) {
                              return (searchBooksList != null &&
                                      searchBooksList != [] &&
                                      (searchBooksList.isNotEmpty ?? false))
                                  ? Column(
                                      children: [
                                        Container(
                                          color: Colors.white,
                                          height: MediaQuery.of(context)
                                              .size
                                              .height,
                                          child: ListView.builder(
                                            scrollDirection: Axis.vertical,
                                            itemCount: searchBooksList.length,
                                            physics:
                                                NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            // itemExtent: 100,
                                            // scrollDirection: Axis.vertical,
                                            itemBuilder: (BuildContext context,
                                                int index) {
                                              return Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        15.0, 15.0, 15.0, 0),
                                                child: Expanded(
                                                  child: Column(
                                                    children: [
                                                      Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Container(
                                                            height: 75,
                                                            width: 50,
                                                            // color: Colors.red,

                                                            child: ClipRRect(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          4.0),
                                                              child:
                                                                  Image.network(
                                                                searchBooksList[
                                                                        index]
                                                                    .volumeInfo
                                                                    .imageLinks
                                                                    .thumbnail,
                                                                fit: BoxFit
                                                                    .cover,
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 16.0,
                                                          ),
                                                          Flexible(
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      bottom:
                                                                          10.0),
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text(
                                                                    searchBooksList[
                                                                            index]
                                                                        .volumeInfo
                                                                        .title,
                                                                    style:
                                                                        TextStyle(
                                                                      color: Colors
                                                                          .black,
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                    ),
                                                                    maxLines: 2,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                  ),
                                                                  Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        top:
                                                                            6.0),
                                                                    child: Text(
                                                                      searchBooksList[
                                                                              index]
                                                                          .volumeInfo
                                                                          .title,
                                                                      style: TextStyle(
                                                                          color:
                                                                              LABEL_COLOR,
                                                                          fontSize:
                                                                              13.0),
                                                                    ),
                                                                  )
                                                                ],
                                                              ),
                                                            ),
                                                          ),

                                                          // Spacer(),
                                                        ],
                                                      ),
                                                      // SizedBox(
                                                      //   height: 5.0,
                                                      // )
                                                    ],
                                                  ),
                                                ),
                                              );
                                              // return Container(
                                              //   height: 100.0,
                                              //   color: Colors.red,
                                              // );
                                            },
                                          ),
                                        ),
                                      ],
                                    )
                                  : CircularProgressIndicator();
                            },
                          ),
                        );
                      }),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

onChanged(BuildContext context, String value) {
  SearchBooksPageBlocWithProvider bloc =
      Provider.of<SearchBooksPageBlocWithProvider>(context, listen: false);
  bloc.onChanged(value);
}
