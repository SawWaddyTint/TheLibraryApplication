import 'package:GooglePlayBooks/resources/colors.dart';
import 'package:flutter/material.dart';

class BookView extends StatelessWidget {
  final double _margin;
  final Function tapMore;
  final double _height;
  final double _width;
  final bool showHeadphone;
  final bool showSample;
  BookView(this._margin, this.tapMore, this._height, this._width,
      {this.showHeadphone = false, this.showSample = false});
  @override
  Widget build(BuildContext context) {
    // return Container(
    //   margin: EdgeInsets.only(right: _margin),
    //   width: 100.0,
    //   height: 200.0,
    //   child: Column(
    //     // textDirection: TextDirection.,
    //     crossAxisAlignment: CrossAxisAlignment.start,
    //     children: [
    //       GestureDetector(
    //         onTap: () {
    //           // onTapMovie(mMovie.id);
    //         },
    //         child: Stack(
    //           children: [
    //             ClipRRect(
    //               borderRadius: BorderRadius.circular(8.0),
    //               child: Image.network(
    //                 "https://www.adazing.com/wp-content/uploads/2012/09/firefly-lane.jpg",
    //                 fit: BoxFit.cover,
    //                 // height: 150.0,
    //               ),
    //             ),
    //           ],
    //         ),
    //       ),
    //       SizedBox(height: 10.0),
    //       Text(
    //         "REMEMBRANCE OF THINGS PAST BY MARCEL PROUST",
    //         style: TextStyle(
    //           color: Colors.grey,
    //           fontWeight: FontWeight.w700,
    //           fontSize: 10.0,
    //         ),
    //       ),
    //     ],
    //   ),
    // );
    return Container(
      width: _width,
      // height: _height,
      margin: EdgeInsets.only(right: _margin),
      child: Column(
        children: [
          Stack(
            children: [
              Positioned.fill(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8.0),
                  child: Image.network(
                    "https://images-na.ssl-images-amazon.com/images/I/41rQf+0zGiL._SX332_BO1,204,203,200_.jpg",

                    // fit: BoxFit.fill,
                    // height: 200.0,
                  ),
                ),
              ),
              // Align(
              //   alignment: Alignment.topLeft,
              //   child: Padding(
              //     padding: const EdgeInsets.all(8.0),
              //     child: Container(
              //       height: 25.0,
              //       width: 70.0,
              //       decoration: BoxDecoration(
              //         color: Color.fromRGBO(63, 64, 66, 0.8),
              //         borderRadius: BorderRadius.circular(4.0),
              //       ),
              //       child: Center(
              //         child: Text(
              //           "Sample",
              //           style: TextStyle(color: Colors.white),
              //         ),
              //       ),
              //     ),
              //   ),
              // ),
              GestureDetector(
                child: Align(
                  alignment: Alignment.topRight,
                  child: Container(
                    child: Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Icon(Icons.more_horiz, color: Colors.white),
                    ),
                  ),
                ),
                onTap: () {
                  this.tapMore();
                },
              ),
              Visibility(
                visible: showSample,
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: 25.0,
                      width: 70.0,
                      decoration: BoxDecoration(
                        color: Color.fromRGBO(63, 64, 66, 0.8),
                        borderRadius: BorderRadius.circular(4.0),
                      ),
                      child: Center(
                        child: Text(
                          "Sample",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              // Align(
              //   alignment: Alignment.bottomRight,
              //   child: Padding(
              //     padding: const EdgeInsets.fromLTRB(0, 0, 8.0, 18.0),
              //     child: Container(
              //       height: 25.0,
              //       width: 25.0,
              //       decoration: BoxDecoration(
              //         color: Color.fromRGBO(63, 64, 66, 0.8),
              //         borderRadius: BorderRadius.circular(4.0),
              //       ),
              //       child: Icon(
              //         Icons.download_done_outlined,
              //         color: Colors.white,
              //       ),
              //     ),
              //   ),
              // ),
              // Align(
              //   alignment: Alignment.bottomCenter,
              //   child: Padding(
              //     padding: const EdgeInsets.all(8.0),
              //     child: LinearProgressIndicator(
              //       valueColor: new AlwaysStoppedAnimation<Color>(LABEL_COLOR),
              //       value: 10.0,
              //     ),
              //   ),
              // ),
              Visibility(
                visible: showHeadphone,
                child: Align(
                  alignment: Alignment.bottomLeft,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0, 0, 8.0, 18.0),
                    child: Container(
                      height: 23.0,
                      width: 23.0,
                      decoration: BoxDecoration(
                        color: Color.fromRGBO(63, 64, 66, 0.8),
                        borderRadius: BorderRadius.circular(4.0),
                      ),
                      child: Icon(
                        Icons.headset,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 5.0,
                top: 100.0,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(0, 0, 8.0, 18.0),
                  child: Container(
                    height: 25.0,
                    width: 25.0,
                    decoration: BoxDecoration(
                      color: Color.fromRGBO(63, 64, 66, 0.8),
                      borderRadius: BorderRadius.circular(4.0),
                    ),
                    child: Icon(
                      Icons.download_done_outlined,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 10.0),
          Text(
            "Standing Tall:The Goh Chok Tong Years,Volumne 2",
            style: TextStyle(
              color: Colors.grey,
              fontWeight: FontWeight.w700,
              fontSize: 10.0,
            ),
          ),
          // SizedBox(
          //   height: 30.0,
          // )
        ],
      ),
    );
  }
}
