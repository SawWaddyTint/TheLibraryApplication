// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'panelization_summary_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PanelizationSummaryVO _$PanelizationSummaryVOFromJson(
    Map<String, dynamic> json) {
  return PanelizationSummaryVO(
    json['containsEpubBubbles'] as bool,
    json['containsImageBubbles'] as bool,
  );
}

Map<String, dynamic> _$PanelizationSummaryVOToJson(
        PanelizationSummaryVO instance) =>
    <String, dynamic>{
      'containsEpubBubbles': instance.containsEpubBubbles,
      'containsImageBubbles': instance.containsImageBubbles,
    };
