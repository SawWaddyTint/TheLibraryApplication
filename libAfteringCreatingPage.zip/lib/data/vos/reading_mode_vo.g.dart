// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'reading_mode_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReadingModeVO _$ReadingModeVOFromJson(Map<String, dynamic> json) {
  return ReadingModeVO(
    json['text'] as bool,
    json['image'] as bool,
  );
}

Map<String, dynamic> _$ReadingModeVOToJson(ReadingModeVO instance) =>
    <String, dynamic>{
      'text': instance.text,
      'image': instance.image,
    };
