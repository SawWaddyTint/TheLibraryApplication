import 'dart:ui';

import 'package:TheLibraryApplication/bloc/shelf_bloc_with_provider.dart';
import 'package:TheLibraryApplication/data/vos/shelf_vo.dart';
import 'package:TheLibraryApplication/resources/colors.dart';
import 'package:TheLibraryApplication/search_books_page.dart';
import 'package:TheLibraryApplication/your_shelves_page.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

bool hasSameName = false;

class CreateShelfPage extends StatefulWidget {
  @override
  _CreateShelfPageState createState() => _CreateShelfPageState();
}

class _CreateShelfPageState extends State<CreateShelfPage> {
  TextEditingController textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (BuildContext context) => ShelfBlocWithProvider(),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          automaticallyImplyLeading: false,
          elevation: 0,
          title: Selector<ShelfBlocWithProvider, bool>(
              selector: (context, bloc) => bloc.hasValue,
              builder: (BuildContext context, hasValue, Widget child) {
                return Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      (hasValue)
                          ? InkWell(
                              child: Container(
                                height: 16.0,
                                width: 16.0,
                                child: Image.asset(
                                  "lib/assets/tick.png",
                                  fit: BoxFit.fill,
                                  color: Colors.blue,
                                  // width: 5.0,
                                  // height: 5.0,
                                ),
                              ),
                              onTap: () {
                                ShelfBlocWithProvider bloc =
                                    Provider.of<ShelfBlocWithProvider>(context,
                                        listen: false);
                                bloc.checkShelfName(context,
                                    ShelfVO("", textController.text, []));
                                // Navigator.pop(context);
                                // checkShelfName(context,
                                //     ShelfVO("", textController.text, []));
                              },
                            )
                          // IconButton(icon: FaIcon(FontAwesomeIcons.),)
                          : InkWell(
                              child: Icon(
                                Icons.arrow_back_ios,
                                color: LABEL_COLOR,
                                size: 20.0,
                              ),
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),
                      SizedBox(
                        width: 100.0,
                      ),
                      Text(
                        "Create shelf",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 22.0,
                        ),
                      ),
                    ],
                  ),
                );
              }),
          //   leading: (hasValue)?
          //     Container(
          //           height: 5.0,
          //           width: 5.0,
          //           child: Image.asset(
          //             "lib/assets/tick.png",
          //             fit: BoxFit.fill,
          //             // width: 5.0,
          //             // height: 5.0,
          //           ),
          //         )
          //       // IconButton(icon: FaIcon(FontAwesomeIcons.),)
          //       : Icon(Icons.arrow_back_ios, color: LABEL_COLOR),
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Selector<ShelfBlocWithProvider, bool>(
                selector: (context, bloc) => bloc.showCreatedShelf,
                builder:
                    (BuildContext context, showCreatedShelf, Widget child) {
                  return Visibility(
                    visible: !showCreatedShelf,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: TextField(
                        controller: textController,
                        style: TextStyle(
                          fontSize: 28.0,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: InputDecoration(
                          hintText: "Shelf name ",
                          suffix: GestureDetector(
                            child: Container(
                              height: 21.0,
                              width: 21.0,
                              decoration: BoxDecoration(
                                  color: Color.fromRGBO(
                                    63,
                                    64,
                                    66,
                                    0.8,
                                  ),
                                  shape: BoxShape.circle),
                              child: Icon(
                                Icons.clear_outlined,
                                color: Colors.white,
                                size: 14.0,
                              ),
                            ),
                            onTap: () {
                              ShelfBlocWithProvider bloc =
                                  Provider.of<ShelfBlocWithProvider>(context,
                                      listen: false);
                              bloc.onChanged("");
                              textController.clear();
                            },
                          ),
                        ),
                        onChanged: (value) => onChanged(context, value),
                        onSubmitted: (value) => _onSubmitted(context, value),
                        maxLength: 50,
                      ),
                    ),
                  );
                }),
            Selector<ShelfBlocWithProvider, bool>(
                selector: (context, bloc) => bloc.showCreatedShelf,
                builder:
                    (BuildContext context, showCreatedShelf, Widget child) {
                  return Visibility(
                    visible: showCreatedShelf,
                    child: Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Selector<ShelfBlocWithProvider, List<ShelfVO>>(
                          selector: (context, bloc) => bloc.shelfList,
                          builder:
                              (BuildContext context, shelfList, Widget child) {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                (shelfList.length > 0)
                                    ? Text(
                                        shelfList[shelfList.length - 1]
                                            .shelfName,
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 22.0,
                                        ),
                                      )
                                    : Container(),
                                Padding(
                                  padding: const EdgeInsets.only(top: 8.0),
                                  child: Text(
                                    "0 books",
                                    style: TextStyle(
                                      color: LABEL_COLOR,
                                      fontSize: 16.0,
                                    ),
                                  ),
                                )
                              ],
                            );
                          }),
                    ),
                  );
                }),
            Divider(
              thickness: 1.0,
            ),
            // Spacer(),
            Expanded(
              child: Selector<ShelfBlocWithProvider, bool>(
                  selector: (context, bloc) => bloc.showCreatedShelf,
                  builder:
                      (BuildContext context, showCreatedShelf, Widget child) {
                    return Visibility(
                      visible: showCreatedShelf,
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(70.0, 100.0, 0, 0.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset(
                              "lib/assets/no_shelves.png",
                              height: 120.0,
                              width: 120.0,
                            ),
                            Text(
                              "No books on this shelf",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 20.0,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 16.0),
                              child: Text(
                                "Add some books in your library from the \nbook's ---menu",
                                style: TextStyle(
                                  color: LABEL_COLOR,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    );
                  }),
            )
          ],
        ),
      ),
    );
  }
}

onChanged(BuildContext context, String value) {
  ShelfBlocWithProvider bloc =
      Provider.of<ShelfBlocWithProvider>(context, listen: false);
  bloc.onChanged(value);
}

_onSubmitted(BuildContext context, String value) {
  ShelfBlocWithProvider bloc =
      Provider.of<ShelfBlocWithProvider>(context, listen: false);
  bloc.checkShelfName(context, ShelfVO("", value, []));
}
