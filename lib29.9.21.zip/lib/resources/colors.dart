import 'package:flutter/material.dart';

const APP_THEME_COLOR = Color.fromRGBO(9, 122, 202, 1.0);
const LABEL_COLOR = Color.fromRGBO(93, 97, 102, 1.0);
const TITLE_COLOR = Color.fromRGBO(34, 34, 36, 1.0);
