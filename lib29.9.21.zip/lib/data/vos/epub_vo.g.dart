// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'epub_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EpubVO _$EpubVOFromJson(Map<String, dynamic> json) => EpubVO(
      json['isAvailable'] as bool?,
    );

Map<String, dynamic> _$EpubVOToJson(EpubVO instance) => <String, dynamic>{
      'isAvailable': instance.isAvailable,
    };
