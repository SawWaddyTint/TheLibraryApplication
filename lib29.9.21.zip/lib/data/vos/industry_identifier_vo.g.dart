// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'industry_identifier_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

IndustryIdentifierVO _$IndustryIdentifierVOFromJson(
        Map<String, dynamic> json) =>
    IndustryIdentifierVO(
      json['type'] as String?,
      json['identifier'] as String?,
    );

Map<String, dynamic> _$IndustryIdentifierVOToJson(
        IndustryIdentifierVO instance) =>
    <String, dynamic>{
      'type': instance.type,
      'identifier': instance.identifier,
    };
