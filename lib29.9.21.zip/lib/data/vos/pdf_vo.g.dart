// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pdf_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PdfVO _$PdfVOFromJson(Map<String, dynamic> json) => PdfVO(
      json['isAvailable'] as bool?,
    );

Map<String, dynamic> _$PdfVOToJson(PdfVO instance) => <String, dynamic>{
      'isAvailable': instance.isAvailable,
    };
