// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'search_info_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SearchInfoVO _$SearchInfoVOFromJson(Map<String, dynamic> json) => SearchInfoVO(
      textSnippet: json['textSnippet'] as String,
    );

Map<String, dynamic> _$SearchInfoVOToJson(SearchInfoVO instance) =>
    <String, dynamic>{
      'textSnippet': instance.textSnippet,
    };
