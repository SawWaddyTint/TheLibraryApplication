// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'image_link_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ImageLinkVO _$ImageLinkVOFromJson(Map<String, dynamic> json) => ImageLinkVO(
      json['smallThumbnail'] as String?,
      json['thumbnail'] as String?,
    );

Map<String, dynamic> _$ImageLinkVOToJson(ImageLinkVO instance) =>
    <String, dynamic>{
      'smallThumbnail': instance.smallThumbnail,
      'thumbnail': instance.thumbnail,
    };
