import 'package:TheLibraryApplication/data/models/book_model.dart';
import 'package:TheLibraryApplication/data/models/book_model_impl.dart';
import 'package:TheLibraryApplication/data/vos/book_list_vo.dart';
import 'package:TheLibraryApplication/data/vos/books_by_list_name_vo.dart';
import 'package:flutter/foundation.dart';

class HomePageBlocWithProvider extends ChangeNotifier {
  // ChangeNotifier must be imported from flutter foundation

  // States
  List<BookListVO> bookLists;
  List<BooksByListNameVO> readBookList;

  /// Models
  BookModel bookModel = BookModelImpl();

  HomePageBlocWithProvider() {
    //   mMovieModel.getBookOverviewList().then((bList) {
    //     bookLists = bList;
    //     notifyListeners();
    //   }).catchError((error) {
    //     debugPrint(error.toString());
    //   });
    // }
    bookModel.getBookOverviewListFromDatabase().listen((bList) {
      bookLists = bList;
      notifyListeners();
    }).onError((error) {
      debugPrint(error.toString());
    });
    bookModel.getReadBooksFromDatabase().listen((bList) {
      readBookList = bList;
    }).onError((error) {
      debugPrint(error.toString());
    });
  }
}
