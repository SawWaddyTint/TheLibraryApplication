import 'package:TheLibraryApplication/data/vos/book_list_vo.dart';
import 'package:TheLibraryApplication/data/vos/books_by_list_name_vo.dart';
import 'package:TheLibraryApplication/persistance/hive_constants.dart';
import 'package:hive/hive.dart';

class BooksByListNameDao {
  static final BooksByListNameDao _singleton = BooksByListNameDao._internal();

  factory BooksByListNameDao() {
    return _singleton;
  }
  BooksByListNameDao._internal();

  void saveAllBooksByListName(List<BooksByListNameVO> bookList) async {
    Map<int, BooksByListNameVO> bookListMap = Map.fromIterable(bookList,
        key: (list) => list.rank, value: (list) => list);
    await getBooksByListNameBox().clear();
    await getBooksByListNameBox().putAll(bookListMap);
  }

  List<BooksByListNameVO> getAllBooksByListName() {
    return getBooksByListNameBox().values.toList();
  }

  Box<BooksByListNameVO> getBooksByListNameBox() {
    return Hive.box<BooksByListNameVO>(BOX_NAME_BOOKS_BY_LIST_NAME_VO);
  }

  /// reactive programming
  Stream<void> getAllBooksByListNameEventStream() {
    return getBooksByListNameBox().watch();
  }

  Stream<List<BooksByListNameVO>> getAllBooksByListNameStream() {
    return Stream.value(getAllBooksByListName().toList());
  }

  List<BooksByListNameVO> getBooksByListName() {
    if (getAllBooksByListName() != null &&
        (getAllBooksByListName().isNotEmpty ?? false)) {
      return getAllBooksByListName().toList();
    } else {
      return [];
    }
  }
}
