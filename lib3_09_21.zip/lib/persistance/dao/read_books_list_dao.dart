import 'package:TheLibraryApplication/data/vos/book_list_vo.dart';
import 'package:TheLibraryApplication/data/vos/books_by_list_name_vo.dart';
import 'package:TheLibraryApplication/persistance/hive_constants.dart';
import 'package:hive/hive.dart';

class ReadBooksListDao {
  static final ReadBooksListDao _singleton = ReadBooksListDao._internal();

  factory ReadBooksListDao() {
    return _singleton;
  }
  ReadBooksListDao._internal();

  // void saveReadBooks(List<BooksByListNameVO> bookList) async {
  //   Map<int, BooksByListNameVO> bookListMap = Map.fromIterable(bookList,
  //       key: (list) => list.listId, value: (list) => list);
  //   await getBookListBox().putAll(bookListMap);
  // }
  void saveReadBooks(BooksByListNameVO book) async {
    List<BooksByListNameVO> bookList;
    bookList.add(book);
    Map<int, BooksByListNameVO> bookListMap = Map.fromIterable(bookList,
        key: (list) => list.bookDetails[0].primaryIsbn10,
        value: (list) => list);
    await getBookListBox().putAll(bookListMap);
  }

  List<BooksByListNameVO> getReadBooksList() {
    return getBookListBox().values.toList();
  }

  Box<BooksByListNameVO> getBookListBox() {
    return Hive.box<BooksByListNameVO>(BOX_NAME_BOOK_LIST_VO);
  }

  /// reactive programming
  Stream<void> getAllReadBookListEventStream() {
    return getBookListBox().watch();
  }

  Stream<List<BooksByListNameVO>> getAllBookListStream() {
    return Stream.value(getReadBooksList().toList());
  }

  List<BooksByListNameVO> getAllReadBookLists() {
    if (getReadBooksList() != null &&
        (getReadBooksList().isNotEmpty ?? false)) {
      return getReadBooksList().toList();
    } else {
      return [];
    }
  }
}
