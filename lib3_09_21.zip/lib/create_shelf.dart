import 'dart:ui';

import 'package:TheLibraryApplication/resources/colors.dart';
import 'package:TheLibraryApplication/your_shelves_page.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

List<String> createdShelves = [];

class CreateShelfPage extends StatefulWidget {
  @override
  _CreateShelfPageState createState() => _CreateShelfPageState();
}

class _CreateShelfPageState extends State<CreateShelfPage> {
  int charLength = 0;
  TextEditingController textController = TextEditingController();
  bool hasValue = false;
  bool showCreatedShelf = false;

  _onChanged(String value) {
    setState(() {
      charLength = value.length;
    });

    if (charLength > 0) {
      setState(() {
        hasValue = true;
        //leadingIcon = Icon(Icons.download_done_outlined, color: LABEL_COLOR);
      });
    } else {
      setState(() {
        hasValue = false;
        //leadingIcon = Icon(Icons.arrow_back_ios, color: LABEL_COLOR);
      });
    }
  }

  getCreatedShelves() {
    setState(() {
      createdShelves.add(textController.text);
      debugPrint(createdShelves.toString());
      showCreatedShelf = true;
      hasValue = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        elevation: 0,
        title: Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              (hasValue)
                  ? GestureDetector(
                      child: Container(
                        height: 16.0,
                        width: 16.0,
                        child: Image.asset(
                          "lib/assets/tick.png",
                          fit: BoxFit.fill,
                          color: Colors.blue,
                          // width: 5.0,
                          // height: 5.0,
                        ),
                      ),
                      onTap: () {
                        getCreatedShelves();
                      },
                    )
                  // IconButton(icon: FaIcon(FontAwesomeIcons.),)
                  : GestureDetector(
                      child: Icon(
                        Icons.arrow_back_ios,
                        color: LABEL_COLOR,
                        size: 20.0,
                      ),
                      onTap: () {
                        Navigator.pop(context, createdShelves);
                      },
                    ),
              SizedBox(
                width: 100.0,
              ),
              Text(
                "Create shelf",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 22.0,
                ),
              ),
            ],
          ),
        ),
        //   leading: (hasValue)?
        //     Container(
        //           height: 5.0,
        //           width: 5.0,
        //           child: Image.asset(
        //             "lib/assets/tick.png",
        //             fit: BoxFit.fill,
        //             // width: 5.0,
        //             // height: 5.0,
        //           ),
        //         )
        //       // IconButton(icon: FaIcon(FontAwesomeIcons.),)
        //       : Icon(Icons.arrow_back_ios, color: LABEL_COLOR),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Visibility(
            visible: !showCreatedShelf,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                controller: textController,
                style: TextStyle(
                  fontSize: 28.0,
                  fontWeight: FontWeight.w600,
                ),
                decoration: InputDecoration(
                  hintText: "Shelf name ",
                  suffix: GestureDetector(
                    child: Container(
                      height: 21.0,
                      width: 21.0,
                      decoration: BoxDecoration(
                          color: Color.fromRGBO(
                            63,
                            64,
                            66,
                            0.8,
                          ),
                          shape: BoxShape.circle),
                      child: Icon(
                        Icons.clear_outlined,
                        color: Colors.white,
                        size: 14.0,
                      ),
                    ),
                    onTap: () {
                      _onChanged("");
                      textController.clear();
                    },
                  ),
                ),
                onChanged: _onChanged,
                maxLength: 50,
              ),
            ),
          ),
          Visibility(
            visible: showCreatedShelf,
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  (createdShelves.length > 0)
                      ? Text(
                          createdShelves[createdShelves.length - 1],
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 22.0,
                          ),
                        )
                      : Container(),
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: Text(
                      "0 books",
                      style: TextStyle(
                        color: LABEL_COLOR,
                        fontSize: 16.0,
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Divider(
            thickness: 1.0,
          ),
          Spacer(),
          Visibility(
            visible: showCreatedShelf,
            child: Padding(
              padding: EdgeInsets.fromLTRB(70.0, 0, 0, 180.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "No books on this shelf",
                    style: TextStyle(
                      color: LABEL_COLOR,
                      fontSize: 20.0,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 16.0),
                    child: Text(
                      "Add some books in your library from the \nbook's ---menu",
                      style: TextStyle(
                        color: LABEL_COLOR,
                      ),
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
