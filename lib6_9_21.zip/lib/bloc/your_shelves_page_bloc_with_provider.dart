import 'package:TheLibraryApplication/data/models/book_model.dart';
import 'package:TheLibraryApplication/data/models/book_model_impl.dart';
import 'package:TheLibraryApplication/data/vos/shelf_vo.dart';
import 'package:uuid/uuid.dart';

import 'package:flutter/foundation.dart';

class YourShelvesPageBlocWithProvider extends ChangeNotifier {
  // ChangeNotifier must be imported from flutter foundation

  // States

  List<String> createdShelves = [];
  List<ShelfVO> allCreatedShelves = [];
  var uuid = Uuid();
  bool showList = false;

  /// Models
  BookModel bookModel = BookModelImpl();
  int charLength = 0;
  YourShelvesPageBlocWithProvider() {
    bookModel.getShelfListFromDatabase().listen((list) {
      allCreatedShelves = list;
      if (allCreatedShelves.length > 0) {
        showList = true;
      } else
        showList = false;
      notifyListeners();
    }).onError((error) {
      debugPrint(error.toString());
    });
  }
}
