import 'package:TheLibraryApplication/data/models/book_model.dart';
import 'package:TheLibraryApplication/data/models/book_model_impl.dart';
import 'package:TheLibraryApplication/data/vos/book_vo.dart';

import 'package:TheLibraryApplication/data/vos/books_by_list_name_vo.dart';
import 'package:flutter/foundation.dart';

class YourBooksPageBlocWithProvider extends ChangeNotifier {
  // ChangeNotifier must be imported from flutter foundation

  // States

  List<BookVO> readBooks;
  int layoutIndexForBooks = 1;

  /// Models
  BookModel bookModel = BookModelImpl();

  YourBooksPageBlocWithProvider({String listName}) {
    //   mMovieModel.getBooksByListName(listName).then((bList) {
    //     booksbyListName = bList;
    //     notifyListeners();
    //   }).catchError((error) {
    //     debugPrint(error.toString());
    //   });
    // }

    bookModel.getReadBooksFromDatabase().listen((bList) {
      readBooks = bList;
      layoutIndexForBooks = 1;
      notifyListeners();
    }).onError((error) {
      debugPrint(error.toString());
    });
  }

  void changeLayoutStyle(int layoutIndex) {
    if (layoutIndex == 1) {
      layoutIndexForBooks = 1;
      notifyListeners();
    } else if (layoutIndex == 2) {
      layoutIndexForBooks = 2;
      notifyListeners();
    } else {
      layoutIndexForBooks = 3;
      notifyListeners();
    }
  }

  List<String> selectedType = [];
  List<String> filterType = [
    "Downloaded",
    "Not downloaded",
    "Not started",
    "In progress",
  ];

  int selectedView;
  // bool showClose = false;
  bool showDowloadAndNotDownloaded = true;
  // bool showNotDownloaded = true;
  bool showNotStartedAndShowInProgess = true;
  // bool showInProgress = true;
  bool showSelectedFilter = false;

  bool showListView = true;
  bool showLargeGrid = false;
  bool showSmallGrid = false;
  int layoutIndex;
  void getSelectedItems(String selected) {
    if (selected == "Downloaded") {
      _addItemToSelectedType(selected);

      showDowloadAndNotDownloaded = false;
      showSelectedFilter = true;
      notifyListeners();
    }

    if (selected == "Not downloaded") {
      _addItemToSelectedType(selected);

      showDowloadAndNotDownloaded = false;
      showSelectedFilter = true;
      notifyListeners();
    }

    if (selected == "Not started") {
      _addItemToSelectedType(selected);
      showNotStartedAndShowInProgess = false;
      showSelectedFilter = true;
      notifyListeners();
    }

    if (selected == "In progress") {
      _addItemToSelectedType(selected);

      showNotStartedAndShowInProgess = false;
      showSelectedFilter = true;
      notifyListeners();
    }

    // if (selectedType.length > 0) {
    //   showSelectedFilter = true;
    //   notifyListeners();
    // } else
    //   showSelectedFilter = false;
    // notifyListeners();
  }

  void _addItemToSelectedType(String type) {
    selectedType.add(type);

    notifyListeners();
  }

  void removeFilters() {
    selectedType = [];
    showSelectedFilter = false;
    showDowloadAndNotDownloaded = true;
    showNotStartedAndShowInProgess = true;
    notifyListeners();
  }
}
