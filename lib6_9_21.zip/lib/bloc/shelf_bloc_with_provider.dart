import 'package:TheLibraryApplication/data/models/book_model.dart';
import 'package:TheLibraryApplication/data/models/book_model_impl.dart';
import 'package:TheLibraryApplication/data/vos/book_vo.dart';
import 'package:TheLibraryApplication/data/vos/shelf_vo.dart';
import 'package:uuid/uuid.dart';

import 'package:flutter/foundation.dart';

class ShelfBlocWithProvider extends ChangeNotifier {
  // ChangeNotifier must be imported from flutter foundation

  // States

  List<ShelfVO> shelfList;
  List<String> createdShelves = [];
  var uuid = Uuid();

  /// Models
  BookModel bookModel = BookModelImpl();
  int charLength = 0;
  YourBooksPageBlocWithProvider({String listName}) {
    //   mMovieModel.getBooksByListName(listName).then((bList) {
    //     booksbyListName = bList;
    //     notifyListeners();
    //   }).catchError((error) {
    //     debugPrint(error.toString());
    //   });
    // }

    bookModel.getShelfListFromDatabase().listen((list) {
      shelfList = list;

      notifyListeners();
    }).onError((error) {
      debugPrint(error.toString());
    });
  }

  bool hasValue = false;
  bool showCreatedShelf = false;

  onChanged(String value) {
    charLength = value.length;

    if (charLength > 0) {
      hasValue = true;
      //leadingIcon = Icon(Icons.download_done_outlined, color: LABEL_COLOR);

    } else {
      hasValue = false;
      //leadingIcon = Icon(Icons.arrow_back_ios, color: LABEL_COLOR);

    }
  }

  saveCreatedShelf(ShelfVO shelf) {
    shelf.id = uuid.v4();
    _saveShelf(shelf);
  }

  _saveShelf(ShelfVO shelf) {
    bookModel.saveShelf(shelf);
  }
}
