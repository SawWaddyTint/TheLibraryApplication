import 'package:TheLibraryApplication/bloc/your_books_page_bloc_with_provider.dart';
import 'package:TheLibraryApplication/create_shelf.dart';
import 'package:TheLibraryApplication/resources/colors.dart';
import 'package:TheLibraryApplication/view_items/book_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class YourBooksPage extends StatefulWidget {
  @override
  _YourBooksPageState createState() => _YourBooksPageState();
}

int _radioSelected = 1;
int _sortedRadioSelected = 1;

class _YourBooksPageState extends State<YourBooksPage> {
  List<String> selectedType = [];
  List<String> filterType = [
    "Downloaded",
    "Not downloaded",
    "Not started",
    "In progress",
  ];
  Icon changedIcon = Icon(
    Icons.list_alt,
    size: 19.0,
    color: LABEL_COLOR,
  );
  int selectedView;
  // bool showClose = false;
  bool showDowloadAndNotDownloaded = true;
  // bool showNotDownloaded = true;
  bool showNotStartedAndShowInProgess = true;
  // bool showInProgress = true;
  bool showSelectedFilter = false;

  bool showListView = true;
  bool showLargeGrid = false;
  bool showSmallGrid = false;
  int layoutIndex;
  getSelectedItems(String selected) {
    setState(() {
      if (selected == "Downloaded") {
        selectedType.add("Downloaded");
        showDowloadAndNotDownloaded = false;
      }

      if (selected == "Not downloaded") {
        selectedType.add("Not downloaded");
        showDowloadAndNotDownloaded = false;
      }

      if (selected == "Not started") {
        selectedType.add("Not started");
        showNotStartedAndShowInProgess = false;
      }

      if (selected == "In progress") {
        selectedType.add("In progress");
        showNotStartedAndShowInProgess = false;
      }

      if (selectedType.length > 0) {
        showSelectedFilter = true;
      } else
        showSelectedFilter = false;
    });
  }

  removeFilters() {
    setState(() {
      selectedType = [];
      showSelectedFilter = false;
      showDowloadAndNotDownloaded = true;
      showNotStartedAndShowInProgess = true;
    });
  }

  getRadioValue(int passedValue) {
    setState(() {
      selectedView = passedValue;
      if (selectedView == 1) {
        showListView = true;
        changedIcon = Icon(
          Icons.grid_on_outlined,
          size: 18.0,
          color: LABEL_COLOR,
        );
      } else
        showListView = false;

      if (selectedView == 2) {
        showLargeGrid = true;
        changedIcon = Icon(
          Icons.list_alt,
          size: 19.0,
          color: LABEL_COLOR,
        );
      } else
        showLargeGrid = false;
      if (selectedView == 3) {
        showSmallGrid = true;
        changedIcon = Icon(
          Icons.list_alt,
          size: 19.0,
          color: LABEL_COLOR,
        );
      } else
        showSmallGrid = false;
    });
  }

  getSortedByRadioValue(int value) {
    debugPrint("Choosen Sorted By value is  " + value.toString());
  }

  @override
  Widget build(BuildContext context) {
    // return Container(
    //   height: 800,
    //   child: NotificationListener(
    //       child: ListView(
    //     children: [
    //       Column(
    //         children: [
    //           ListView(scrollDirection: Axis.horizontal, children: [
    //             Stack(
    //               children: [
    //                 Positioned(
    //                   child: Container(
    //                     height: 25.0,
    //                     width: 25.0,
    //                     decoration: BoxDecoration(
    //                       color: Colors.white,
    //                       border: Border.all(),
    //                       borderRadius: BorderRadius.circular(50.0),
    //                     ),
    //                   ),
    //                 ),
    //                 Align(
    //                   alignment: Alignment.center,
    //                   child: Icon(
    //                     Icons.close,
    //                     color: Colors.black,
    //                   ),
    //                 )
    //               ],
    //             ),
    //           ])
    //         ],
    //       ),
    //     ],
    //   )),
    // );
    return ChangeNotifierProvider(
      create: (BuildContext context) {
        YourBooksPageBlocWithProvider();
      },
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            FilterView(
              showSelectedFilter: showSelectedFilter,
              selectedType: selectedType,
              showDowloadAndNotDownloaded: showDowloadAndNotDownloaded,
              filterType: filterType,
              showNotStartedAndShowInProgess: showNotStartedAndShowInProgess,
              getSelectedItems: (type) => getSelectedItems(type),
              removeFilters: () => removeFilters(),
            ),
            // SizedBox(
            //   height: 8.0,
            // ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14.0, 14.0, 0, 8.0),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Row(
                      children: [
                        SortedByView(
                          (value) => getSortedByRadioValue(value),
                        ),

                        // SizedBox(
                        //   width: 150.0,
                        // ),
                        Spacer(),
                        ChooseBooksView((int passedVal) {
                          getRadioValue(passedVal);
                        }, changedIcon, layoutIndex),
                      ],
                    ),
                  )
                ],
              ),
            ),
            BooksListView(showListView: showListView),
            BooksLargeGridView(showLargeGrid: showLargeGrid),
            BooksSmallGridView(showSmallGrid: showSmallGrid),
          ],
        ),
      ),
    );
  }
}

class SortedByView extends StatelessWidget {
  final Function getSortedByRadioValue;
  SortedByView(this.getSortedByRadioValue);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Row(
        children: [
          Icon(
            Icons.sort,
            color: LABEL_COLOR,
            size: 22.0,
          ),
          // SortedByView(
          //   (value) => getSortedByRadioValue(value),
          // ),
          SizedBox(
            width: 10.0,
          ),
          Text(
            "Sort by: Recent",
            style: TextStyle(
              color: LABEL_COLOR,
              fontSize: 15.0,
            ),
          ),
        ],
      ),
      onTap: () {
        showModalBottomSheet(
          useRootNavigator: true,
          context: context,
          builder: (BuildContext context) {
            return StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height / 2.8,
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                          padding:
                              const EdgeInsets.fromLTRB(30.0, 12.0, 0.0, 0.0),
                          child: Text(
                            "View as",
                            style: TextStyle(
                                color: LABEL_COLOR,
                                fontSize: 18.0,
                                fontWeight: FontWeight.bold),
                          )),
                      Divider(
                        thickness: 1.0,
                        height: 28.0,
                      ),
                      Column(
                        children: [
                          RadioListTile(
                            value: 1,
                            groupValue: _sortedRadioSelected,
                            onChanged: (value) {
                              setState(() {
                                _sortedRadioSelected = value;
                              });

                              _close(context);
                              getSortedByRadioValue(value);
                            },
                            title: Text("Recently opened"),
                          ),
                          RadioListTile(
                            value: 2,
                            groupValue: _sortedRadioSelected,
                            onChanged: (value) {
                              setState(() {
                                _sortedRadioSelected = value;
                              });
                              // getRadioValue(value);
                              _close(context);
                              getSortedByRadioValue(value);
                            },
                            title: Text("Title"),
                          ),
                          RadioListTile(
                            value: 3,
                            groupValue: _sortedRadioSelected,
                            onChanged: (value) {
                              setState(() {
                                _sortedRadioSelected = value;
                              });
                              _close(context);
                              getSortedByRadioValue(value);
                            },
                            title: Text("Author"),
                          )
                        ],
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}

class BooksSmallGridView extends StatelessWidget {
  const BooksSmallGridView({
    Key key,
    @required this.showSmallGrid,
  }) : super(key: key);

  final bool showSmallGrid;

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: showSmallGrid,
      child: Container(
        height: MediaQuery.of(context).size.height,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14.0, 12.0, 14.0, 0),
          child: GridView.builder(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 10.0,
              childAspectRatio: MediaQuery.of(context).size.width /
                  (MediaQuery.of(context).size.height / 0.92),
            ),
            itemCount: 20,
            itemBuilder: (context, index) {
              return BookView(
                150,
                100,
                () {},
                showSample: true,
                showDownload: true,
              );
            },
          ),
        ),
      ),
    );
  }
}

class BooksLargeGridView extends StatelessWidget {
  const BooksLargeGridView({
    Key key,
    @required this.showLargeGrid,
  }) : super(key: key);

  final bool showLargeGrid;

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: showLargeGrid,
      child: Container(
        height: MediaQuery.of(context).size.height,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14.0, 12.0, 14.0, 0),
          child: GridView.builder(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 11.0,
              childAspectRatio: MediaQuery.of(context).size.width /
                  (MediaQuery.of(context).size.height / 1.01),
            ),
            itemCount: 20,
            itemBuilder: (context, index) {
              return BookView(
                230,
                100,
                () {},
                showDownload: true,
                showSample: true,
              );
            },
          ),
        ),
      ),
    );
  }
}

class BooksListView extends StatelessWidget {
  const BooksListView({
    Key key,
    @required this.showListView,
  }) : super(key: key);

  final bool showListView;

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: showListView,
      child: ListView.builder(
        itemCount: 8,
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        // itemExtent: 100,
        // scrollDirection: Axis.vertical,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(15.0, 15.0, 15.0, 0),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 75,
                      width: 50,
                      // color: Colors.red,

                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4.0),
                        child: Image.network(
                          "https://images-na.ssl-images-amazon.com/images/I/41rQf+0zGiL._SX332_BO1,204,203,200_.jpg",
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 16.0,
                    ),
                    Flexible(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 10.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "Standing Tall:The Goh Chok Tong Years,Volumne 2",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 14.0,
                                fontWeight: FontWeight.w600,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 6.0),
                              child: Text(
                                "Shing huei Peh, Chok Tong Goh\nEbook . Sample",
                                style: TextStyle(
                                    color: LABEL_COLOR, fontSize: 13.0),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 30.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.download_done_outlined,
                              color: LABEL_COLOR,
                              size: 16.0,
                            ),
                            onPressed: () {
                              // navigateToShelfDetailsPage(context);
                            },
                          ),
                          IconButton(
                            icon: Icon(
                              Icons.more_horiz,
                              color: LABEL_COLOR,
                              size: 20.0,
                            ),
                            onPressed: () {
                              // navigateToShelfDetailsPage(context);
                            },
                          ),
                        ],
                      ),
                    ),
                    // Spacer(),
                  ],
                ),
                // SizedBox(
                //   height: 5.0,
                // )
              ],
            ),
          );
          // return Container(
          //   height: 100.0,
          //   color: Colors.red,
          // );
        },
      ),
    );
  }
}

class ChooseBooksView extends StatelessWidget {
  final Function getRadioValue;
  final Icon _icon;
  int layoutIndex;
  ChooseBooksView(this.getRadioValue, this._icon, this.layoutIndex);

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: _icon,
      onPressed: () {
        showModalBottomSheet(
          useRootNavigator: true,
          context: context,
          builder: (BuildContext context) {
            return StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height / 2.8,
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                          padding:
                              const EdgeInsets.fromLTRB(30.0, 12.0, 0.0, 0.0),
                          child: Text(
                            "View as",
                            style: TextStyle(
                                color: LABEL_COLOR,
                                fontSize: 18.0,
                                fontWeight: FontWeight.bold),
                          )),
                      Divider(
                        thickness: 1.0,
                        height: 28.0,
                      ),
                      Column(
                        children: [
                          RadioListTile(
                            value: 1,
                            groupValue: _radioSelected,
                            onChanged: (value) {
                              setState(() {
                                _radioSelected = value;
                              });

                              _close(context);
                              YourBooksPageBlocWithProvider bloc =
                                  Provider.of<YourBooksPageBlocWithProvider>(
                                      context,
                                      listen: false);
                              bloc.changeLayoutStyle(value);
                            },
                            title: Text("List"),
                          ),
                          RadioListTile(
                            value: 2,
                            groupValue: _radioSelected,
                            onChanged: (value) {
                              setState(() {
                                _radioSelected = value;
                              });
                              // getRadioValue(value);
                              _close(context);
                              YourBooksPageBlocWithProvider bloc =
                                  Provider.of<YourBooksPageBlocWithProvider>(
                                      context,
                                      listen: false);
                              bloc.changeLayoutStyle(value);
                            },
                            title: Text("Large grid"),
                          ),
                          RadioListTile(
                            value: 3,
                            groupValue: _radioSelected,
                            onChanged: (value) {
                              setState(() {
                                _radioSelected = value;
                              });
                              _close(context);
                              YourBooksPageBlocWithProvider bloc =
                                  Provider.of<YourBooksPageBlocWithProvider>(
                                      context,
                                      listen: false);
                              bloc.changeLayoutStyle(value);
                            },
                            title: Text("Small grid"),
                          )
                        ],
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}

void _close(BuildContext ctx) {
  Navigator.of(ctx).pop();
}

class FilterView extends StatelessWidget {
  const FilterView({
    Key key,
    @required this.showSelectedFilter,
    @required this.selectedType,
    @required this.showDowloadAndNotDownloaded,
    @required this.filterType,
    @required this.showNotStartedAndShowInProgess,
    @required this.removeFilters,
    @required this.getSelectedItems,
  }) : super(key: key);

  final bool showSelectedFilter;
  final List<String> selectedType;
  final bool showDowloadAndNotDownloaded;
  final List<String> filterType;
  final bool showNotStartedAndShowInProgess;
  final Function removeFilters;
  final Function getSelectedItems;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(14.0, 18.0, 0, 0),
      child: Container(
        height: 37.0,
        width: double.infinity,
        color: Colors.transparent,
        child: ListView(
          scrollDirection: Axis.horizontal,
          shrinkWrap: true,
          children: [
            RemoveFilterButtonView(
                showSelectedFilter: showSelectedFilter,
                removeFilters: removeFilters),
            Visibility(
              visible: showSelectedFilter,
              child: SizedBox(
                width: 10.0,
              ),
            ),
            SelectedFilterTypesView(
                selectedType: selectedType,
                showSelectedFilter: showSelectedFilter),
            Visibility(
              visible: showSelectedFilter,
              child: SizedBox(
                width: 10.0,
              ),
            ),
            FilterTypesView(
                showDowloadAndNotDownloaded: showDowloadAndNotDownloaded,
                filterType: filterType,
                getSelectedItems: getSelectedItems,
                showNotStartedAndShowInProgess: showNotStartedAndShowInProgess)
          ],
        ),
      ),
    );
  }
}

class FilterTypesView extends StatelessWidget {
  const FilterTypesView({
    Key key,
    @required this.showDowloadAndNotDownloaded,
    @required this.filterType,
    @required this.getSelectedItems,
    @required this.showNotStartedAndShowInProgess,
  }) : super(key: key);

  final bool showDowloadAndNotDownloaded;
  final List<String> filterType;
  final Function getSelectedItems;
  final bool showNotStartedAndShowInProgess;

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      scrollDirection: Axis.horizontal,
      // physics: ClampingScrollPhysics(),
      children: [
        GestureDetector(
          child: Visibility(
            visible: showDowloadAndNotDownloaded,
            child: Container(
              width: 100.0,
              height: 10.0,
              // height: 32.0,
              decoration: BoxDecoration(
                  // color: Color.fromRGBO(4, 82, 130, 1.0),
                  color: Colors.transparent,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(18.0),
                    bottomLeft: Radius.circular(18.0),
                  ),
                  border: Border.all(width: 0.15)),
              child: Center(
                child: FilterTypeText(filterType[0]),
              ),
            ),
          ),
          onTap: () {
            getSelectedItems(filterType[0]);
          },
        ),
        GestureDetector(
          child: Visibility(
            visible: showDowloadAndNotDownloaded,
            child: Container(
              width: 110.0,
              height: 10.0,
              // height: 32.0,
              decoration: BoxDecoration(
                // color: Color.fromRGBO(4, 82, 130, 1.0),
                color: Colors.transparent,
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(18.0),
                  bottomRight: Radius.circular(18.0),
                ),
                border: Border.all(width: 0.15),
              ),
              child: Center(
                child: FilterTypeText(filterType[1]),
              ),
            ),
          ),
          onTap: () {
            getSelectedItems(filterType[1]);
          },
        ),
        SizedBox(
          width: 10.0,
        ),
        GestureDetector(
          child: Visibility(
            visible: showNotStartedAndShowInProgess,
            child: Container(
              width: 100.0,
              height: 10.0,
              // height: 32.0,
              decoration: BoxDecoration(
                // color: Color.fromRGBO(4, 82, 130, 1.0),
                color: Colors.transparent,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(18.0),
                  bottomLeft: Radius.circular(18.0),
                ),
                border: Border.all(width: 0.15),
              ),
              child: Center(
                child: FilterTypeText(filterType[2]),
              ),
            ),
          ),
          onTap: () {
            getSelectedItems(filterType[2]);
          },
        ),
        GestureDetector(
          child: Visibility(
            visible: showNotStartedAndShowInProgess,
            child: Container(
              width: 100.0,
              height: 10.0,
              // height: 32.0,
              decoration: BoxDecoration(
                // color: Color.fromRGBO(4, 82, 130, 1.0),
                color: Colors.transparent,
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(18.0),
                  bottomRight: Radius.circular(18.0),
                ),
                border: Border.all(width: 0.15),
              ),
              child: Center(
                child: FilterTypeText(filterType[3]),
              ),
            ),
          ),
          onTap: () {
            getSelectedItems(filterType[3]);
          },
        ),
      ],
    );
  }
}

class FilterTypeText extends StatelessWidget {
  final String _text;
  FilterTypeText(this._text);

  @override
  Widget build(BuildContext context) {
    return Text(
      _text,
      style: TextStyle(
        color: LABEL_COLOR,
        fontWeight: FontWeight.w500,
      ),
    );
  }
}

class SelectedFilterTypesView extends StatelessWidget {
  const SelectedFilterTypesView({
    Key key,
    @required this.selectedType,
    @required this.showSelectedFilter,
  }) : super(key: key);

  final List<String> selectedType;
  final bool showSelectedFilter;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      scrollDirection: Axis.horizontal,
      itemCount: selectedType.length,
      itemBuilder: (BuildContext context, int index) {
        return Visibility(
          visible: showSelectedFilter,
          child: Container(
            margin: (selectedType.length > 1)
                ? EdgeInsets.only(right: 10.0)
                : EdgeInsets.only(right: 0.0),
            width: 110.0,
            height: 10.0,
            // height: 32.0,
            decoration: BoxDecoration(
              color: Color.fromRGBO(4, 82, 130, 1.0),
              // color: Colors.transparent,
              borderRadius: BorderRadius.circular(18.0),
              border: Border.all(width: 0.15),
            ),
            child: Center(
              child: Text(
                selectedType[index],
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        );
      },
    );
  }
}

class RemoveFilterButtonView extends StatelessWidget {
  const RemoveFilterButtonView({
    Key key,
    @required this.showSelectedFilter,
    @required this.removeFilters,
  }) : super(key: key);

  final bool showSelectedFilter;
  final Function removeFilters;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Visibility(
        visible: showSelectedFilter,
        child: Container(
          // height: 32.0,
          width: 32.0,
          decoration: BoxDecoration(
            color: Colors.transparent,
            shape: BoxShape.circle,
            border: Border.all(width: 0.3),
          ),
          child: Center(
            child: Icon(
              Icons.close,
              color: Colors.black,
              size: 18.0,
            ),
          ),
        ),
      ),
      onTap: () {
        removeFilters();
      },
    );
  }
}
