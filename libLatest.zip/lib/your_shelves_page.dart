import 'package:TheLibraryApplication/create_shelf.dart';
import 'package:TheLibraryApplication/resources/colors.dart';
import 'package:TheLibraryApplication/shelf_details_page.dart';
import 'package:flutter/material.dart';

List<String> allCreatedShelves = [];
// List<String> createdShelves

class YourShelvesPage extends StatefulWidget {
  // const YourShelvesPage({ Key? key }) : super(key: key);

  @override
  _YourShelvesPageState createState() => _YourShelvesPageState();
}

class _YourShelvesPageState extends State<YourShelvesPage> {
  bool showList = false;
  _navigateToCreateShelvesPage(BuildContext context) async {
    allCreatedShelves = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CreateShelfPage(),
      ),
    );
    debugPrint(
        "All created shelves in shelf page >>" + allCreatedShelves.toString());
    setState(() {
      if (allCreatedShelves.length > 0) {
        showList = true;
      } else
        showList = false;
      allCreatedShelves = allCreatedShelves;
    });
  }

  @override
  void initState() {
    super.initState();

    allCreatedShelves = allCreatedShelves;
    debugPrint("shelves in shelf page" + allCreatedShelves.toString());
  }

  _navigateToShelfDetailsPage(context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ShelfDetailsPage(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: [
            ShelvesListView(
                showList: showList,
                navigateToShelfDetailsPage: (context) {
                  _navigateToShelfDetailsPage(context);
                }),
            // NoShelvesMessageView(showList: showList),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 12.0),
        child: new FloatingActionButton.extended(
          backgroundColor: APP_THEME_COLOR,
          onPressed: () {
            _navigateToCreateShelvesPage(context);
          },
          icon: Icon(
            Icons.edit_outlined,
            color: Colors.white,
            size: 18.0,
          ),
          label: Text("Create new"),
        ),
      ),
    );
  }
}

class NoShelvesMessageView extends StatelessWidget {
  const NoShelvesMessageView({
    Key key,
    @required this.showList,
  }) : super(key: key);

  final bool showList;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Visibility(
        visible: showList,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("No Shelves"),
            Text("Create shelves to match the way you think")
          ],
        ),
      ),
    );
  }
}

class ShelvesListView extends StatelessWidget {
  const ShelvesListView({
    Key key,
    @required this.showList,
    @required this.navigateToShelfDetailsPage,
  }) : super(key: key);

  final bool showList;
  final Function navigateToShelfDetailsPage;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(15.0, 35.0, 15.0, 0),
      child: Positioned.fill(
        child: Column(
          children: [
            InkWell(
              child: Row(
                children: [
                  Container(
                    height: 65,
                    width: 65,
                    // color: Colors.red,

                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6.0),
                      child: Image.network(
                        "https://images-na.ssl-images-amazon.com/images/I/41rQf+0zGiL._SX332_BO1,204,203,200_.jpg",
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10.0,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          "Waddy's Shelf",
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18.0,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text(
                            "10 books",
                            style: TextStyle(
                              color: LABEL_COLOR,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Spacer(),
                  IconButton(
                    icon: Icon(
                      Icons.arrow_forward_ios,
                      color: LABEL_COLOR,
                      size: 18.0,
                    ),
                    onPressed: () {
                      navigateToShelfDetailsPage(context);
                    },
                  )
                ],
              ),
              onTap: () {
                navigateToShelfDetailsPage(context);
              },
            ),
            Divider(
              thickness: 1,
              height: 0.8,
            ),
            Visibility(
              visible: showList,
              child: Padding(
                padding: EdgeInsets.only(
                  top: 14.0,
                ),
                child: ListView.builder(
                    itemCount: allCreatedShelves.length,
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    // itemExtent: 100,
                    // scrollDirection: Axis.vertical,
                    itemBuilder: (BuildContext context, int index) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                height: 65,
                                width: 65,

                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(6.0),
                                  color: Color.fromRGBO(219, 220, 225, 1.0),
                                ),
                                // child: ClipRRect(
                                //   borderRadius: BorderRadius.circular(6.0),
                                //   child: Image.network(
                                //     "https://images-na.ssl-images-amazon.com/images/I/41rQf+0zGiL._SX332_BO1,204,203,200_.jpg",
                                //     fit: BoxFit.cover,
                                //   ),
                                // ),
                              ),
                              SizedBox(
                                width: 10.0,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(bottom: 20.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      allCreatedShelves[index],
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 18.0,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 8.0),
                                      child: Text(
                                        "0 book",
                                        style: TextStyle(
                                          color: LABEL_COLOR,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Spacer(),
                              IconButton(
                                  icon: Icon(
                                    Icons.arrow_forward_ios,
                                    color: LABEL_COLOR,
                                    size: 18.0,
                                  ),
                                  onPressed: null)
                            ],
                          ),
                          Divider(),
                        ],
                      );
                    }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
