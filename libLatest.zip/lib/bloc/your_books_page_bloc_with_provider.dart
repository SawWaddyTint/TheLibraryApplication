import 'package:TheLibraryApplication/data/models/book_model.dart';
import 'package:TheLibraryApplication/data/models/book_model_impl.dart';
import 'package:TheLibraryApplication/data/vos/book_vo.dart';

import 'package:TheLibraryApplication/data/vos/books_by_list_name_vo.dart';
import 'package:flutter/foundation.dart';

class YourBooksPageBlocWithProvider extends ChangeNotifier {
  // ChangeNotifier must be imported from flutter foundation

  // States

  List<BookVO> booksbyListName;
  int layoutIndexForBooks;

  /// Models
  BookModel bookModel = BookModelImpl();

  YourBooksPageBlocWithProvider({String listName}) {
    //   mMovieModel.getBooksByListName(listName).then((bList) {
    //     booksbyListName = bList;
    //     notifyListeners();
    //   }).catchError((error) {
    //     debugPrint(error.toString());
    //   });
    // }

    bookModel.getBooksByListNameFromDatabase(listName).listen((bList) {
      booksbyListName = bList;
      notifyListeners();
    }).onError((error) {
      debugPrint(error.toString());
    });
  }

  void saveToReadBooks(BookVO book) {
    bookModel.saveReadBooks(book);
  }

  void changeLayoutStyle(int layoutIndex) {
    if (layoutIndex == 1) {
      layoutIndexForBooks = 1;
      notifyListeners();
    } else if (layoutIndex == 2) {
      layoutIndexForBooks = 2;
      notifyListeners();
    } else {
      layoutIndexForBooks = 3;
      notifyListeners();
    }
  }
}
