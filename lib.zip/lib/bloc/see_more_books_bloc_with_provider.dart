import 'package:TheLibraryApplication/data/models/book_model.dart';
import 'package:TheLibraryApplication/data/models/book_model_impl.dart';

import 'package:TheLibraryApplication/data/vos/books_by_list_name_vo.dart';
import 'package:flutter/foundation.dart';

class SeeMoreBooksBlocWithProvider extends ChangeNotifier {
  // ChangeNotifier must be imported from flutter foundation

  // States

  List<BooksByListNameVO> booksbyListName;

  /// Models
  BookModel mMovieModel = BookModelImpl();

  SeeMoreBooksBlocWithProvider(String listName) {
    mMovieModel.getBooksByListName(listName).then((bList) {
      booksbyListName = bList;
      notifyListeners();
    }).catchError((error) {
      debugPrint(error.toString());
    });
  }
}
