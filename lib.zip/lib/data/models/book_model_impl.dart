import 'package:TheLibraryApplication/data/models/book_model.dart';
import 'package:TheLibraryApplication/data/vos/book_list_vo.dart';
import 'package:TheLibraryApplication/data/vos/books_by_list_name_vo.dart';
import 'package:TheLibraryApplication/network/book_data_agent.dart';
import 'package:TheLibraryApplication/network/retrofit_data_agent_impl.dart';
import 'package:TheLibraryApplication/persistance/dao/book_list_dao.dart';
import 'package:stream_transform/stream_transform.dart';

class BookModelImpl extends BookModel {
  BookDataAgent bDataAgent = RetrofitDataAgentImpl();
  static final BookModelImpl _singleton = BookModelImpl._internal();

  factory BookModelImpl() {
    return _singleton;
  }

  BookModelImpl._internal();
  //Daos

  BookListDao bookListDao = BookListDao();
  // GenreDao mGenreDao = GenreDao();
  // ActorDao mActorDao = ActorDao();

  @override
  Future<List<BookListVO>> getBookOverviewList() {
    return bDataAgent.getBookOverviewList().then((bookList) {
      bookListDao.saveAllBooks(bookList);
      return Future.value(bookList);
    });
  }

  @override
  Future<List<BooksByListNameVO>> getBooksByListName(String listName) {
    return bDataAgent.getBooksByListName(listName).then((bookList) {
      // bookListDao.saveAllBooks(bookList);
      return Future.value(bookList);
    });
  }

  // @override
  // Future<List<BookListVO>> getBookOverviewListFromDatabase() {
  //   this.getBookOverviewList();
  //   return bookListDao
  //       .getAllBookListEventStream()
  //       .startWith(bookListDao.getAllBookListStream())
  //       .combineLatest(bookListDao.getAllBookListStream(),
  //           (event, bookList) => bookList as List<BookListVO>)
  //       .first;
  // }

  //   @override
  // Future<List<BooksByListNameVO>> getBooksByListNameFromDatabase(String listName) {
  //   this.getBooksByListName(listName);
  //   return bookListDao
  //       .getAllBookListEventStream()
  //       .startWith(bookListDao.getAllBookListStream())
  //       .combineLatest(bookListDao.getAllBookListStream(),
  //           (event, bookList) => bookList as List<BookListVO>)
  //       .first;
  // }

  @override
  Stream<List<BookListVO>> getBookOverviewListFromDatabase() {
    this.getBookOverviewList();
    return bookListDao
        .getAllBookListEventStream()
        .startWith(bookListDao.getAllBookListStream())
        .map((event) => bookListDao.getBookLists());
  }
}
