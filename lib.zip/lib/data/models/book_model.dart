import 'package:TheLibraryApplication/data/vos/book_list_vo.dart';
import 'package:TheLibraryApplication/data/vos/books_by_list_name_vo.dart';

abstract class BookModel {
  Future<List<BookListVO>> getBookOverviewList();
  Future<List<BooksByListNameVO>> getBooksByListName(String listName);

  Stream<List<BookListVO>> getBookOverviewListFromDatabase();
  // Future<List<BooksByListNameVO>> getBooksByListNameFromDatabase(
  //     String listName);
}
