//Hive Types
const int HIVE_TYPE_ID_BOOK_LIST_VO = 1;
const int HIVE_TYPE_ID_BOOK_VO = 2;
const int HIVE_TYPE_ID_BUY_LINKS_VO = 3;
const int HIVE_TYPE_ID_BOOK_OVERVIEW_RESULT_VO = 4;
const int HIVE_TYPE_ID_BOOKS_BY_LIST_NAME_VO = 5;
const int HIVE_TYPE_ID_ISBNS_VO = 6;
const int HIVE_TYPE_ID_BOOK_DETAILS_VO = 7;
const int HIVE_TYPE_ID_REVIEWS_VO = 8;
const int HIVE_TYPE_ID_SNACK_VO = 9;
const int HIVE_TYPE_PROFILE_VO = 10;

//Box Names
const String BOX_NAME_BOOK_LIST_VO = "BOX_NAME_BOOK_LIST_VO";
