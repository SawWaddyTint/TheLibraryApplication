// import 'dart:html';

import 'package:TheLibraryApplication/resources/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class BookDetailsPage extends StatelessWidget {
  final double _width;
  final double _height;
  final String _text;
  final bool showBtnIcon;
  BookDetailsPage(this._width, this._height, this._text,
      {this.showBtnIcon = false});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        // automaticallyImplyLeading: false,
        leading: GestureDetector(
          child: Icon(
            Icons.arrow_back_ios,
            color: LABEL_COLOR,
            size: 20.0,
          ),
          onTap: () {
            Navigator.pop(context);
          },
        ),
        title: Padding(
          padding: const EdgeInsets.only(left: 40.0),
          child: Text(
            "About this book",
            style: TextStyle(
              color: Colors.black,
              fontSize: 20.0,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: GestureDetector(
              child: Icon(
                Icons.more_horiz,
                color: LABEL_COLOR,
                size: 22.0,
              ),
              onTap: () {
                // showActionSheet(context);
              },
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 16.0, 20.0, 0),
              child: BookImageAndTitleView(_width, _height),
            ),
            Divider(
              thickness: 0.8,
              height: 35.0,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 0, 20.0, 8.0),
              child: Row(
                children: [
                  BookDetailsScreenButtonView(
                    _text,
                    APP_THEME_COLOR,
                    Colors.white,
                    showBtnIcon: showBtnIcon,
                  ),
                  Spacer(),
                  BookDetailsScreenButtonView(
                    "Get the full book",
                    Colors.white,
                    APP_THEME_COLOR,
                    isGhostBtn: true,
                  ),
                ],
              ),
            ),
            Divider(
              thickness: 0.8,
              height: 20.0,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 12.0, 20.0, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  RatingView(),
                  SizedBox(
                    height: 15.0,
                  ),
                  BookDescriptionView(),
                  BookPublishedInfoView(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class BookImageAndTitleView extends StatelessWidget {
  final double _width;
  final double _height;
  BookImageAndTitleView(this._width, this._height);

  @override
  Widget build(BuildContext context) {
    return Row(
      // mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          height: _height,
          width: _width,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(6.0),
            child: Image.network(
              "https://images-na.ssl-images-amazon.com/images/I/41rQf+0zGiL._SX332_BO1,204,203,200_.jpg",
              fit: BoxFit.fill,
            ),
          ),
        ),
        SizedBox(
          width: 18.0,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              "Beating the Street",
              style: TextStyle(
                color: Colors.black,
                fontSize: 22.0,
                fontWeight: FontWeight.w600,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 6.0),
              child: Text(
                "Peter Lynch \nEbook . 336 pages",
                style: TextStyle(color: LABEL_COLOR),
              ),
            )
          ],
        ),
      ],
    );
  }
}

class BookPublishedInfoView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      // mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Text(
          "Published",
          style: TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(
          height: 15.0,
        ),
        Text(
          "13 March 2012 . Simonand Schuster",
          style: TextStyle(
            color: LABEL_COLOR,
            fontSize: 14.0,
          ),
        ),
        SizedBox(
          height: 14.0,
        ),
      ],
    );
  }
}

class BookDescriptionView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Description",
          style: TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(
          height: 15.0,
        ),
        Text(
          "Legendary money manager Peter Lynch explains his own strategies for investing and offers advice for how to pick stocks and mutual funds to assemble a successful investment portfolio.Develop a Winning Investment Strategy—with Expert Advice from “The Nation’s #1 Money Manager.” Peter Lynch’s “invest in what you know” strategy has made him a household name with investors both big and small.An important key to investing, Lynch says, is to remember that stocks are not lottery tickets. There’s a company behind every stock and a reason companies—and their stocks—perform the way they do. In this book, Peter Lynch shows you how you can become an expert in a company and how you can build a profitable investment portfolio, based on your own experience and insights and on straightforward do-it-yourself research.In Beating the Street, Lynch for the first time explains how to devise a mutual fund strategy, shows his step-by-step strategies for picking stock, and describes how the individual investor can improve his or her investment performance to rival that of the experts.There’s no reason the individual investor can’t match wits with the experts, and this book will show you how.",
          style: TextStyle(
            color: LABEL_COLOR,
          ),
        ),
        SizedBox(
          height: 24.0,
        ),
      ],
    );
  }
}

class RatingView extends StatelessWidget {
  const RatingView({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              "4.4",
              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
                fontWeight: FontWeight.w600,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: RatingBar.builder(
                initialRating: 4.5,
                itemBuilder: (BuildContext context, int index) {
                  return Icon(
                    Icons.star,
                    color: Colors.black,
                  );
                },
                itemSize: 16.0,
                onRatingUpdate: (rating) {
                  print(rating);
                },
              ),
            )
          ],
        ),
        Text(
          "59 ratings on Google Play",
          style: TextStyle(
            color: LABEL_COLOR,
            fontSize: 12.0,
          ),
        ),
      ],
    );
  }
}

class BookDetailsScreenButtonView extends StatelessWidget {
  final String titleText;
  final Color bgColor;
  final Color textColor;
  final bool isGhostBtn;
  final bool showBtnIcon;
  BookDetailsScreenButtonView(this.titleText, this.bgColor, this.textColor,
      {this.isGhostBtn = false, this.showBtnIcon = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 32.0,
      width: 150.0,
      padding: EdgeInsets.symmetric(
        horizontal: 6.0,
      ),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(4.0),
        border: (isGhostBtn)
            ? Border.all(
                color: Colors.grey,
                width: 0.3,
              )
            : null,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Visibility(
            visible: showBtnIcon,
            child: Icon(
              Icons.play_arrow_sharp,
              color: Colors.white,
              size: 14.0,
            ),
          ),
          SizedBox(
            width: 4.0,
          ),
          Text(
            titleText,
            style: TextStyle(
                color: textColor, fontWeight: FontWeight.w500, fontSize: 13.0),
          ),
        ],
      ),
    );
  }
}
